# Void Jailer Player Character

**This mod is currently in a public test phase. Some content is missing, such as ability icons and survivor lore.** This is mostly here to test mechanics and have a sort of "early access" for the mod.

Balance is a bit off but any insight would be much appreciated (especially given that you can test it yourself, check the configs), you can find me in the Risk of Rain 2 Modding Discord under the nickname "Xan" `Xan // Eti#1760`.

# Interested in my mods?
I have a Discord server dedicated to my mods for all games! You can join it [here](https://discord.gg/YGJ7a44UEE).

# To Do List
* An alternative to Dive (which was copied directly from Reaver anyway).
* Survivor lore