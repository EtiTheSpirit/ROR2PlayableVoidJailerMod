# Void Jailer Player Character

**This mod is currently in a public test phase. Some content is missing, such as ability icons and survivor lore.** This is mostly here to test mechanics and have a sort of "early access" for the mod.

Balance is a bit off but any insight would be much appreciated (especially given that you can test it yourself, check the configs), you can find me in the Risk of Rain 2 Modding Discord under the nickname "Xan" `Xan // Eti#1760`.

# To Do List
* An alternative to Dive (which was copied directly from Reaver anyway).
* Icons for all abilities
* Variant of the Survivor icon that uses a blue outline instead of a red one
* Survivor lore
* Tune all default stats (they are already able to be configured to enable better experiences for modpack users, this is mostly so that it "comes out of the box" with the right numbers)