## 1.0.2
#### pov: you are battling a rock to see what has a higher mental capacity (the rock is winning)
* Fixed a few more rather foolish bugs that could cause things to flat out break in the game.
* Fixed a different type of NRE that was thrown on occasion.

## 1.0.1
#### Yeah, I guess that was my fault.
* Fixed a reflection exception preventing the mod from loading on some clients.

## 1.0.0
#### *"Go feed a bottom you bottom feeder"?* What is that supposed to mean?
* ourple lober gaming
