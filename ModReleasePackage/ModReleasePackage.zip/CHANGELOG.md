## 1.0.1
#### Yeah, I guess that was my fault.
* Fixed a reflection exception preventing the mod from loading on some clients.

## 1.0.0
#### *"Go feed a bottom you bottom feeder"?* What is that supposed to mean?
* ourple lober gaming
