## 1.1.0
#### Okay NOW it works. I hope.
* Fixed a few foolish bugs that could completely brick visual effects.
* Fixed an error causing the Jailer to be unusable (stuck, could not activate skills) on remote clients in multiplayer environments.
* Fixed a few bugs relating to missing networking components on objects that needed them.
* Changed stats to be more appropriate.

## 1.0.1
#### Yeah, I guess that was my fault.
* Fixed a reflection exception preventing the mod from loading on some clients.

## 1.0.0
#### *"Go feed a bottom you bottom feeder"?* What is that supposed to mean?
* ourple lober gaming
